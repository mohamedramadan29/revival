	<!-- START NEW NAVABR  -->
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light">
	    <div class="container-fluid">
	        <a class="navbar-brand" href="index.php">Revaval</a>
	        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
	            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	            <span class="navbar-toggler-icon"></span>
	        </button>
	        <div class="collapse navbar-collapse" id="navbarSupportedContent">
	            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
	                <li class="nav-item">
	                    <a class="nav-link active" aria-current="page" href="index.php">HOME</a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="events.php"> Events </a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="event_courses.php"> Courses </a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="dialoge_session.php"> Dialogue sessions </a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="exhibition.php"> Exhibition </a>
	                </li>
	                <li class="nav-item">
	                    <a class="nav-link" href="faq.php"> Login </a>
	                </li>

	            </ul>
	        </div>
	    </div>
	</nav>
	<!-- END NEW NAVBAR -->