<?php

if (isset($_GET['new_id']) && is_numeric($_GET['new_id'])) {
    $new_id = $_GET['new_id'];
    $stmt = $connect->prepare('SELECT * FROM news WHERE new_id=?');
    $stmt->execute([$new_id]);
    $alltype = $stmt->fetch();
    $count = $stmt->rowCount();
    if ($count > 0) { ?>
<div class="container">

    <!-- start new data -->
    <div class="data">
        <div class="bread">
            <nav style="--bs-breadcrumb-divider: '>';" aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"> <i class="fa fa-heart"></i> <a
                            href="main.php?dir=dashboard&page=dashboard"> ريفايفال </a> <i
                            class="fa fa-chevron-left"></i> </li>
                    <li class="breadcrumb-item active" aria-current="page"> الاخبار </li>
                </ol>
            </nav>
        </div>
        <div class="title text-right">
            <h6> <i class="fa fa-edit"></i> الاخبار </h6>
        </div>
        <div class="myform">
            <form class="form-group insert" method="POST" autocomplete="on" enctype="multipart/form-data">
                <input type="hidden" name="typ_id" value="<?php echo $new_id; ?>">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="box">
                            <label id="name"> عنوان الخبر
                            </label>
                            <input required class="form-control" type="text" name="ques"
                                value="<?php echo $alltype["new_title"]; ?>">
                        </div>
                        <div class="box">
                            <label id="name">العنوان باللغه الانجليزية
                            </label>
                            <input required class="form-control" type="text" name="ques_en"
                                value="<?php echo $alltype["new_title_en"]; ?>">
                        </div>
                        <div class="box">
                            <label id="car_color"> اختر القسم </label>
                            <select id="cat_active2" class="form-control" name="category" id="">
                                <option value=""> اختر القسم </option>
                                <option value="art_int"
                                    <?php if ($alltype["new_category"] == "art_int") echo "selected";  ?>> الذكاء
                                    الاصطناعي </option>
                                <option value="sport"
                                    <?php if ($alltype["new_category"] == "sport") echo "selected";  ?>> الرياضة
                                </option>
                                <option value="fashion"
                                    <?php if ($alltype["new_category"] == "fashion") echo "selected";  ?>> الازياء
                                    والموضة </option>

                            </select>
                        </div>
                        <div class="box2">
                            <label for=""> الصورة العربية <span> * </span> </label>
                            <div class="">
                                <input id="logo" class="form-control dropify_"
                                    data-default-file="upload/<?php echo $alltype["image1"]; ?>" type="file"
                                    name="image1" value="">
                            </div>
                            <div id="logo_" class="col-md-3">
                            </div>
                        </div>

                        <div class="box2">
                            <label for=""> الصورة الانجليزية <span> * </span> </label>
                            <div class="">
                                <input id="logo2" class="form-control dropify_"
                                    data-default-file="upload/<?php echo $alltype["image2"]; ?>" type="file"
                                    name="image2" value="">
                            </div>
                            <div id="logo_" class="col-md-3">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="box">
                            <label for=""> محتوي الخبر </label>
                            <textarea name="answer1" id=""
                                class="form-control">  <?php echo $alltype["new_desc"]; ?> </textarea>
                        </div>
                        <div class="box">
                            <label for=""> محتوي الخبر باللغه الانجليزية </label>
                            <textarea name="answer2" id=""
                                class="form-control"> <?php echo $alltype["new_desc_en"]; ?></textarea>
                        </div>
                    </div>
                    <div class="box submit_box">
                        <input class="btn btn-primary" name="add_car" type="submit" value="تعديل الخبر">
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- end new data -->

</div>

<?php if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // START Arabic Image 
            $image1_name = $_FILES['image1']['name'];
            $image1_tem = $_FILES['image1']['tmp_name'];
            $image1_type = $_FILES['image1']['type'];
            $image1_size = $_FILES['image1']['size'];

            $image_allowed_extention = ['jpg', 'jpeg', 'png'];

            // START Engish Arabic
            $image2_name = $_FILES['image2']['name'];
            $image2_tem = $_FILES['image2']['tmp_name'];
            $image2_type = $_FILES['image2']['type'];
            $image2_size = $_FILES['image2']['size'];

            $art_title = $_POST['ques'];
            $art_title_en = $_POST['ques_en'];
            $art_desc = $_POST['answer1'];
            $art_desc_en = $_POST['answer2'];
            $art_category = $_POST['category'];
            $formerror = [];
            if (empty($art_title)) {
                $formerror[] = 'Please Insert Title';
            }
            foreach ($formerror as $errors) {
                echo "<div class='alert alert-danger danger_message'>" .
                    $errors .
                    '</div>';
            }

            if (empty($formerror)) {

                if ($image1_tem != '' && $image2_tem != '') {
                    $image1_uploaded = rand(0, 100000000) . '.' . $image1_name;
                    move_uploaded_file(
                        $image1_tem,
                        'upload/' . $image1_uploaded
                    );

                    $image2_uploaded = rand(0, 100000000) . '.' . $image2_name;
                    move_uploaded_file(
                        $image2_tem,
                        'upload/' . $image2_uploaded
                    );
                    $stmt = $connect->prepare("UPDATE news SET new_title=?,new_title_en=?,
                    new_desc=?,new_desc_en=?,new_category=?,image1=?,image2=?
                        WHERE new_id=?");
                    $stmt->execute([
                        $art_title,
                        $art_title_en,
                        $art_desc,
                        $art_desc_en,
                        $art_category,
                        $image1_uploaded,
                        $image2_uploaded,
                        $new_id
                    ]);
                    if ($stmt) { ?>
<div class="container">
    <div class="alert-success">
        تم تعديل المقال بنجاح

        <?php header('refresh:3,url=main.php?dir=news&page=report'); ?>


    </div>
</div>

<?php }
                } elseif ($image1_tem != '') {
                    $image1_uploaded = rand(0, 100000000) . '.' . $image1_name;
                    move_uploaded_file(
                        $image1_tem,
                        'upload/' . $image1_uploaded
                    );

                    $stmt = $connect->prepare("UPDATE news SET new_title=?,new_title_en=?,
                    new_desc=?,new_desc_en=?,new_category=?,image1=?
                        WHERE new_id=?");
                    $stmt->execute([
                        $art_title,
                        $art_title_en,
                        $art_desc,
                        $art_desc_en,
                        $art_category,
                        $image1_uploaded,
                        $new_id
                    ]);
                    if ($stmt) { ?>
<div class="container">
    <div class="alert-success">
        تم تعديل المقال بنجاح

        <?php header('refresh:3,url=main.php?dir=news&page=report'); ?>


    </div>
</div>

<?php }
                } elseif ($image2_tem != '') {
                    $image2_uploaded = rand(0, 100000000) . '.' . $image2_name;
                    move_uploaded_file(
                        $image2_tem,
                        'upload/' . $image2_uploaded
                    );
                    $stmt = $connect->prepare("UPDATE news SET new_title=?,new_title_en=?,
                    new_desc=?,new_desc_en=?,new_category=?,image2=?
                        WHERE new_id=?");
                    $stmt->execute([
                        $art_title,
                        $art_title_en,
                        $art_desc,
                        $art_desc_en,
                        $art_category,
                        $image2_uploaded,
                        $new_id
                    ]);
                    if ($stmt) { ?>
<div class="container">
    <div class="alert-success">
        تم تعديل المقال بنجاح

        <?php header('refresh:3,url=main.php?dir=news&page=report'); ?>


    </div>
</div>

<?php }
                } else {

                    $stmt = $connect->prepare("UPDATE news SET new_title=?,new_title_en=?,
                    new_desc=?,new_desc_en=?,new_category=?
                        WHERE new_id=?");
                    $stmt->execute([
                        $art_title,
                        $art_title_en,
                        $art_desc,
                        $art_desc_en,
                        $art_category,
                        $new_id
                    ]);
                    if ($stmt) { ?>
<div class="container">
    <div class="alert-success">
        تم تعديل المقال بنجاح

        <?php header('refresh:3,url=main.php?dir=news&page=report'); ?>


    </div>
</div>

<?php }
                }
            }
        }
    }
} else {
    ?>
<div class="container">
    <div class="alert alert-danger"> لا يوجد بيانات لهذا العنصر </div>
</div>
<?php
}