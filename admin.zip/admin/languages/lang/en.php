<?php
	$lang = array(
		"title" => "Add Insurance Company",

		"name" => "Name",
		"english_name" => " English Name",

    "mobile" => " Mobile ",
		"phone" => " Phone  ",
		"address" => " Address  ",
		"image" => " Company Image  ",
    "add_comp" => "Add Maintenance",

		"succ_message" => "Add  Success",
		"edit_message" => "Edit  Success",
		"delete_message" => "Delete  Success",
    // Report Page

    "search" => "Search",
    "total_number" => "Total Number",
    "watch_users" => " Watch Company ",
    "next" => "Next",
    "previous" => "Previous",
    "edit" => "Edit",
    "delete" => "Delete",

    // Edit Customer

    "edit_company" => "Edit Comapny",
		// table date

		"nodata" => "No Data Found",




				////////////////////// START NAVBAR ///////////


						"dashboard" => "Dashboard",
						"customer" => "Customers",
						"add_customer" => "Add Customer",
						"watch_customer" => "Watch Customers",
						"users" => "Users",
						"add_users" => "Add User",
						"watch_users" => "Watch Users",
						"sales_company" => "Sales Company",

						"add_sales_company" => "Add Sales Comapany",
						"watch_sales_company" => "Watch Sales Company",
						"cars" => "Cars",
						"add_car" => "Add Car",

						"watch_car" => "Watch Cars",
						"emp" => "Employee",
						"add_emp" => "Add Employee",
						"watch_emp" => "Watch Employies",

						"rental" => "Rental",
						"add_rental" => "Add Rental ",
						"watch_rental" => "Watch Rental",
						"book" => "Booking",

						"add_book" => "Add Book",
						"watch_book" => "Watch Booking",
						"salary" => "Salary",
						"add_salary" => "Add Salary",

						"watch_salary" => "Watch Salary",
						"repair" => "Repair",
						"add_repair" => "Add Repair",
						"watch_repair" => "Watch Repair",
						"maintaine" => "Maintenance",
						"add_maintaine" => "Add Maintenance",
						"watch_maintain" => "Watch Maintenance",
						"insurance_company" => "Insurance Company",
						"add_insurance_company" => "Add Insurance Comapany",
						"watch_insurance_company" => "Watch Insurance Comapany",
						"expenses" => "Expenses",
						"add_expenses" => " Add Expenses ",
						"watch_expenses" => "Watch Expenses",
						"installment" => "Installment",
						"add_installment" => "Add Installment",
						"watch_installment" => "Watch Installment",
						"reports" => "Reports",
						"car_report" => "Car Reports ",
						"customer_report" => "Customer Reports",
						"emp_report" => "Employee Reports",
						"infraction_report" => "Infraction Reports ",
						"accident_report" => "Accident Reports",
						"installemt" => "Installemt",
						"logout" => "Logout",
						"car_rental" => "Car Rental System",


						



		"lang_en" => "الانجليزية",
		"lang_ar" => "العربية"
	);
?>
